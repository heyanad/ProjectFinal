function refresh() {
    setTimeout(function() {
        location.reload()
    }, 100);
}